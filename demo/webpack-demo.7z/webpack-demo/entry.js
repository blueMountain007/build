var oApp = document.querySelector("#app");
// require("style!css!./style.css");
import modB from './b'
require("./style");     // style.css的简写
// var str = require("./a.js");
oApp.innerHTML  = "hello world" + (modB.a + modB.b + modB.c);
