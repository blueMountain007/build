module.exports={
    entry: './entry.js',
    output: {
        filename: 'bundle.js'
    },
    devtool: 'source-map', //直接生成soruce-map
    module:{
        loaders:[
            {
                test:/\.css$/,
                loader:'style!css'
            },
            {
                test:/\.js$/,
                loader:'babel',
                exclude: /node_modules/  //排除
            }
        ]
    },
    resolve: {
        "extensions": ['', '.js', '.css', '.json', '.jsx'] //可以省略的后缀名
    }
};
